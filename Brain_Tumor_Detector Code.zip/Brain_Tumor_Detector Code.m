function varargout = Brain_Tumor_Detector(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Brain_Tumor_Detector_OpeningFcn, ...
                   'gui_OutputFcn',  @Brain_Tumor_Detector_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Brain_Tumor_Detector is made visible.
function Brain_Tumor_Detector_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for Brain_Tumor_Detector
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = Brain_Tumor_Detector_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in select_mage.
function select_mage_Callback(hObject, eventdata, handles)
% Allow user to select an MRI image
global img1 img2
[path, nofile] = imgetfile();

if nofile
    msgbox('Image not found!!!', 'Error', 'Warning');
    return;
end

img1 = imread(path);
img1 = im2double(img1);
img2 = img1;

axes(handles.axes1);
imshow(img1);
title('\fontsize{20}\color[rgb]{1,0,1} MRI Image');

% --- Executes on button press in meadian_filtering.
function meadian_filtering_Callback(hObject, eventdata, handles)
% Apply median filtering to remove noise
global img1

if size(img1,3) == 3
    img1 = rgb2gray(img1);
end

K = medfilt2(img1);
axes(handles.axes2);
imshow(K);
title('\fontsize{20}\color[rgb]{1,0,1} Median Filter');

% --- Executes on button press in edge_detection.
function edge_detection_Callback(hObject, eventdata, handles)
% Perform edge detection using Sobel operator
global img1

if size(img1,3) == 3
    img1 = rgb2gray(img1);
end

K = medfilt2(img1);
C = double(K);
B = zeros(size(C));

for i = 1:size(C,1)-2
    for j = 1:size(C,2)-2
        % Sobel mask for X-direction
        Gx = ((2*C(i+2,j+1) + C(i+2,j) + C(i+2,j+2)) - (2*C(i,j+1) + C(i,j) + C(i,j+2)));
        % Sobel mask for Y-direction
        Gy = ((2*C(i+1,j+2) + C(i,j+2) + C(i+2,j+2)) - (2*C(i+1,j) + C(i,j) + C(i+2,j)));
        % The Gradient of The Image
        B(i,j) = sqrt(Gx.^2 + Gy.^2);
    end
end

axes(handles.axes3);
imshow(B);
title('\fontsize{20}\color[rgb]{1,0,1} Edge Detection');

% --- Executes on button press in tumor_detection.
function tumor_detection_Callback(hObject, eventdata, handles)
% Detect the tumor region in the MRI image
global img1

K = medfilt2(img1);
bw = imbinarize(K, 0.7);
label = bwlabel(bw);
stats = regionprops(label, 'Solidity', 'Area');

density = [stats.Solidity];
area = [stats.Area];
high_dense_area = density > 0.5;
max_area = max(area(high_dense_area));
tumor_label = find(area == max_area);
tumor = ismember(label, tumor_label);

se = strel('square', 5);
tumor = imdilate(tumor, se);

Bound = bwboundaries(tumor, 'noholes');

axes(handles.axes4);
imshow(K);
hold on;
for i = 1:length(Bound)
    plot(Bound{i}(:,2), Bound{i}(:,1), 'y', 'linewidth', 1.75);
end
title('\fontsize{20}\color[rgb]{1,0,1} Tumor Detected !!!');
hold off;
